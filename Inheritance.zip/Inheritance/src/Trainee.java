
public class Trainee extends Employee{

	public Trainee(long id, String name, String address, long phone, double sal) {
		super(id, name, address, phone, sal);
		// TODO Auto-generated constructor stub
	}

}
