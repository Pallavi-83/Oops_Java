
public class ArrayReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array[]= {5,9,6,8,7,3};
		for(int index= array.length-1;index>=0;index--) {
			System.out.print(array[index]+" ");
		}

	}

}
